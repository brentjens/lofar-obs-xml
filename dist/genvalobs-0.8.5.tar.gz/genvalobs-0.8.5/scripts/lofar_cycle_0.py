from momxml.observation  import *
from momxml.targetsource import *
from momxml.utilities    import *
from momxml.sourcecatalogue import SourceCatalogue

import ephem




cal_list = SourceCatalogue()

target = TargetSource('NGC 891',
                      ra_angle  = Angle(shms = ('+',  2, 22, 33.4)),
                      dec_angle = Angle(sdms = ('+', 42, 20, 57.0)))

calibrator = cal_list.find_source('3C 48')


# target = TargetSource('3C468.1',
#                       ra_angle  = Angle(shms=('+', 23, 50, 54.849)),
#                       dec_angle = Angle(sdms=('+', 64, 40, 19.54)))

# calibrator = TargetSource('3C196',
#                           ra_angle  = Angle(shms=('+', 8, 13, 36.0)),
#                           dec_angle = Angle(sdms=('+', 48, 13, 3.0)))

exclude = ['CS013', 'RS305']

subbands   = [72,73,74,75,77,79,81,82,85,87,89,94,96,97,98,102,104,105,106,107,108,109,110,
111,112,113,114,116,118,119,121,122,123,125,127,128,130,132,134,136,137,138,
139,141,142,144,145,147,148,149,151,152,153,154,157,159,160,161,162,163,165,
167,170,172,173,174,176,177,178,179,182,183,184,186,189,190,191,192,193,194,
196,197,198,200,201,203,204,205,206,207,209,211,212,217,218,220,222,223,225,
226,227,228,230,231,233,234,236,237,238,239,240,242,243,244,245,246,247,249,
251,252,256,257,258,260,261,263,264,265,266,267,269,270,271,273,274,275,276,
277,278,279,280,281,283,284,286,287,288,289,292,293,294,295,296,297,298,299,
301,303,304,306,309,311,312,313,316,317,318,319,320,322,323,325,326,327,328,
331,334,335,336,338,342,343,344,345,346,347,348,352,354,355,360,361,362,363,
364,365,366,367,368,369,370,373,376,377,380,382,384,385,388,389,391,393,394,
396,406,410,412,413,415,424,425,426,428,431,432,435,439,441,443,444,445,446,
447,448,451,452,453,454,455,456,457,458,459,460]

cal_time_s = 60.0
src_time_s = 660.0
gap_s      = 60.0
duration_s = 12*3600.0

cal_beam   = Beam(calibrator, subbands)
src_beam   = Beam(target    , subbands)

start_date = ephem.Date((2012, 11, 1,  16, 0, 1.0))
end_date   = ephem.Date(start_date + duration_s*ephem.second)

observations = []
current_date = start_date
while current_date < end_date:
    observations.append(Observation(
        beam_list        = [cal_beam],
        antenna_set      = 'HBA_DUAL',
        frequency_range  = 'HBA_LOW',
        start_date       = ephem.Date(current_date).tuple(),
        duration_seconds = cal_time_s,
        stations         = station_list('nl', exclude = exclude),
        clock_mhz        = 200,
        integration_time_seconds = 2,
        channels_per_subband     = 64))

    current_date += cal_time_s * ephem.second
    current_date += gap_s      * ephem.second
    
    observations.append(Observation(
        beam_list        = [src_beam],
        antenna_set      = 'HBA_DUAL',
        frequency_range  = 'HBA_LOW',
        start_date       = ephem.Date(current_date).tuple(),
        duration_seconds = src_time_s,
        stations         = station_list('nl', exclude = exclude),
        clock_mhz        = 200,
        integration_time_seconds = 2,
        channels_per_subband     = 64))

    current_date += src_time_s * ephem.second
    current_date += gap_s      * ephem.second
        


observations.append(Observation(
    beam_list        = [cal_beam],
    antenna_set      = 'HBA_DUAL',
    frequency_range  = 'HBA_LOW',
    start_date       = ephem.Date(current_date).tuple(),
    duration_seconds = cal_time_s,
    stations         = station_list('nl', exclude = exclude),
    clock_mhz        = 200,
    integration_time_seconds = 2,
    channels_per_subband     = 64))


print as_xml_mom_project(observations, 'Commissioning2012')
