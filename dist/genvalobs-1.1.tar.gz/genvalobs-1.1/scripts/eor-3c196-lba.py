import momxml
import ephem
import sys
from numpy import sin, cos, sqrt, arctan2, arcsin


def lm_from_ra_dec(ra_angle, dec_angle, ra0_angle, dec0_angle):
    l_rad = cos(float(dec_angle))*sin(float(ra_angle - ra0_angle))
    m_rad = sin(float(dec_angle))*cos(float(dec0_angle)) - cos(float(dec_angle))*sin(float(dec0_angle))*cos(float(ra_angle - ra0_angle))
    return (l_rad, m_rad)


def ra_dec_from_lm(l_rad, m_rad, ra0_angle, dec0_angle):
    n_rad  = sqrt(1.0 - l_rad*l_rad - m_rad*m_rad)
    ra_rad = float(ra0_angle) + arctan2(l_rad,
                                        cos(float(dec0_angle))*n_rad - m_rad*sin(float(dec0_angle)))
    dec_rad = arcsin(m*cos(float(dec0_angle)) + sin(float(dec0_angle))*n_rad)
    return (momxml.Angle(rad=ra_rad), momxml.Angle(rad=dec_rad))


def rotate_lm_CCW(l_rad, m_rad, ccw_angle):
    cs = cos(float(ccw_angle))
    ss = sin(float(ccw_angle))

    l_new =  l_rad*cs + m_rad*ss
    m_new = -l_rad*ss + m_rad*cs
    return l_new, m_new
                

start_search_date = (2013, 3, 2, 18, 0, 0.0)

target       = momxml.TargetSource(name      = '3C196',
                                   ra_angle  = momxml.Angle(shms = ('+', 8, 13, 36.0678)),
                                   dec_angle = momxml.Angle(sdms = ('+', 48, 13, 2.581)))

transit_date = momxml.next_date_with_lofar_lst(target.ra_angle.as_rad(), start_search_date)

target.name = '3C196-%4d-%02d-%02d' % transit_date.tuple()[0:3]



cal_fields   = [momxml.TargetSource(name      = '3C196-LBA-N',
                                    ra_angle  = momxml.Angle(shms = ('+', 8, 13, 36.0678)),
                                    dec_angle = momxml.Angle(sdms = ('+', 53, 13, 2.581)))
                ]
ra_A    = cal_fields[0].ra_angle
dec_A   = cal_fields[0].dec_angle
pos_angle_inc = momxml.Angle(deg = 60.0)

antenna_set     = 'LBA_INNER'
band            = 'LBA_HIGH'
stations        = momxml.station_list('all', exclude=['DE602'])
int_s           = 1.0
chan            = 64
target_subbands = '154..401'
cal_subbands    = '154,160,167,173,179,186,192,198,205,211,217,224,230,236,243,249,255,262,268,274,281,287,293,300,306,312,319,325,331,338,344,350,357,363,369,376,382,388,395,401'
target_duration_s = 8*3600


for i,field_name  in zip(range(5), ['NW', 'SW', 'S', 'SE', 'NE']):
    l0, m0 = lm_from_ra_dec(ra_A, dec_A, target.ra_angle, target.dec_angle)
    rot    = pos_angle_inc*(-(1+i))
    l, m   = rotate_lm_CCW(l0, m0, rot)
    ra_angle, dec_angle = ra_dec_from_lm(l, m, target.ra_angle, target.dec_angle)
    cal_fields.append(momxml.TargetSource('3C196-LBA-'+field_name,
                                          ra_angle  = ra_angle,
                                          dec_angle = dec_angle))

sys.stderr.write('MAIN: '+str(target) + '\n')
for cal in cal_fields:
    sys.stderr.write(' CAL: '+str(cal)+ '\n')


observations = []
current_date = transit_date - 0.5*target_duration_s*ephem.second


observations.append(momxml.Observation(
        beam_list        = [momxml.Beam(target, target_subbands)] + [momxml.Beam(field, cal_subbands) for field in cal_fields],
        antenna_set      = antenna_set,
        frequency_range  = band,
        start_date       = ephem.Date(current_date).tuple(),
        duration_seconds = target_duration_s,
        stations         = stations,
        clock_mhz        = 200,
        integration_time_seconds = int_s,
        channels_per_subband     = chan,
        bit_mode         = 8))

obs_folder = momxml.Folder(name        = 'EoR-3C196',
                           description = '3C 196 observations for the EoR',
                           children    = observations,
                           mom_id      = 182244)

print momxml.as_xml_mom_project([obs_folder], 'LC0_019')
