#! /usr/bin/env python

# XML generator prototype version 9

# mode 1
# mode 2
# mode 3
    # This mode will create multi-beam target observations with coupled calibration pipelines (no imaging)
    # This mode can be used to pre-process raw UV-data (i.e. average in time and frequency, flag RFI, and demix strong A-team sources),
    # and to calibrate these data using a user-supplied sky model.
    
    # This calibration pipeline will perform the following operations:
    
    # 1. Prepare phase, collect data from parset and input mapfiles.
    # 2. Create VDS-file; it will contain important input-data for NDPPP
    # 3. Average and flag data, and demix A-team sources using NDPPP.
    # 4. Create a sourcedb from the user-supplied sky model, and an empty parmdb.
    # 5. Run BBS to calibrate the data.


import sys, getopt, time
from datetime import datetime,timedelta


import logging

def parse_subband_list(parset_subband_list):
    r'''
    Parse a subband list from a parset.

    **Parameters**

    parset_subband_list : string
        Value of Observation.Beam[0].subbandList

    **Returns**

    A list of integers containing the subband numbers.

    **Examples**


    >>> parse_subband_list('[154..163,185..194,215..224,245..254,275..284,305..314,335..344,10*374]')
    [154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 335, 336, 337, 338, 339, 340, 341, 342, 343, 344, 374, 374, 374, 374, 374, 374, 374, 374, 374, 374]

    >>> parse_subband_list('[77..87,116..127,155..166,194..205,233..243,272..282,311..321]')
    [77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321]

    >>> parse_subband_list('[]')
    []
    '''
    stripped_subband_list = parset_subband_list.strip('[] \n\t')
    if stripped_subband_list == '':
        return []
    sub_lists = [word.strip().split('..') for word in stripped_subband_list.split(',')]
    subbands = []
    for sub_list in sub_lists:
        if len(sub_list) == 1:
            multiplication = sub_list[0].split('*')
            if len(multiplication) == 2:
                subbands += [int(multiplication[1])]*int(multiplication[0])
            else:
                subbands.append(int(sub_list[0]))
        elif len(sub_list) == 2:
            subbands += range(int(sub_list[0]), int(sub_list[1])+1)
        else:
            logging.error('%r is not a valid sub_range in a subband list', sub_list)
            return []
    return subbands


def main(argv):
  
  inputfile = ''
  outputfile = ''
  
  try:
     opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])
  except getopt.GetoptError:
     print 'HBAgen.py -i <inputfile> [-o <outputfile>]'
     sys.exit(2)
     
  if len(opts) == 0:
     print 'usage: HBAgen.py -i <inputfile> [-o <outputfile>]'
     sys.exit(2)    

  for opt, arg in opts:
    if opt == '-h':
      print 'usage: HBAgen.py -i <inputfile> [-o <outputfile.xml>]'
      sys.exit()
    elif opt in ("-i", "--ifile"):
      inputfile = arg
    elif opt in ("-o", "--ofile"):
      outputfile = arg

  if len(outputfile):
    print "now opening: " + outputfile
  else:
    print "output file not specified, using the default outputfile template.xml"
    outputfile = 'template.xml'

  ofile = open(outputfile, 'w')

  if len(inputfile):
     ifile = open(inputfile, 'r')
   
  lines = ifile.readlines()
  
  try:
    start_line = 0
    
    nr_lines = len(lines)
    lineNr = 0
    first_block = True;
    first_block_start = False
    blockNr = 0
    mainFolderName = ''
    
    while lineNr+1 < nr_lines:

      packageName = ''
      packageDescription = ''
      packageTag = ''
      startTimeUTC = ''
      timeStep1 = ''
      timeStep2 = ''
      stationList = ''
      antennaMode = ''
      instrumentFilter = ''
      integrationTime = ''
      calibratorDurationSeconds = 0
      targetDurationSeconds = 0
      numberOfBitsPerSample = 0
      channelsPerSubband = 0
      nrSubbandsPerImage = 0
      tbbPiggybackAllowed = 'true'
      skyModel = ''
      nrSlices = 0
      nr_beams = 0
      calibratorBeam = []
      targetBeams = []
      create_calibrator_beam = False
      create_target_cal_beam = False
      create_extra_ncp_beam = False
      create_calibrator_observations = False
      set_starttime = False
      
      for lineNr in range(start_line, nr_lines):
	cline = lines[lineNr]

	if cline.startswith("BLOCK"):
	  if not first_block_start:
	    first_block_start = True
	  else:
	    start_line = lineNr+1
	    break # starts processing the read params after the for loop
	elif lineNr+1 >= nr_lines:
	  break;

	elif not cline.startswith('#'):
	  clinesplit = cline.split('=')
	  if clinesplit[0] == "setup_mode":
	    if len(clinesplit) == 2:
	      mode_str = clinesplit[1].rstrip()
	      if (mode_str == "Calobs"):
		mode = 1
	      elif (mode_str == "Calbeam"):
		mode = 2
	      elif (mode_str == "Preprocessing"):
		mode = 3
	      elif (mode_str == "Calibration"):
		mode = 4
	      else:
		raise Exception("the specified mode '" + mode_str + "' is not recognized. It should be one of 'Calobs', 'Calbeam', 'Preprocessing', 'Calibration'")
	      print "the used setup mode = %s" % mode_str
	    else:
	      raise Exception("the setup mode has not been specified")
	  elif clinesplit[0] == "projectName":
	    if len(clinesplit) == 2:
	      projectName = clinesplit[1].rstrip()
	      print "the project = %s" % projectName
	    else:
	      raise Exception("the projectName has not been specified")
	  elif clinesplit[0] == "mainFolderName":
	    if len(clinesplit) == 2:
	      mainFolderName = clinesplit[1].rstrip()
	      print "the project = %s" % mainFolderName
	    else:
	      raise Exception("the mainFolderName has not been specified")
	  elif clinesplit[0] == "mainFolderDescription":
	    if len(clinesplit) == 2:
	      mainFolderDescription = clinesplit[1].rstrip()
	      print "the project = %s" % mainFolderDescription
	    else:
	      raise Exception("the mainFolderDescription has not been specified")
	  elif clinesplit[0] == "packageName":
	    if len(clinesplit) == 2:
	      packageName = clinesplit[1].rstrip()
	      print "the package name = %s" % packageName
	    else:
	      raise Exception("the packageName has not been specified")	  
	  elif clinesplit[0] == "packageDescription":
	    if len(clinesplit) == 2:
	      packageDescription = clinesplit[1].rstrip()
	      print "the package description = %s" % packageDescription
	    else:
	      raise Exception("the packageDescription has not been specified")	
	  elif clinesplit[0] == "packageTag":
	    if len(clinesplit) == 2:
	      packageTag = clinesplit[1].rstrip()
	      if len(packageTag) > 10:
		raise Exception("the packageTag:'" + packageTag + "' is too long. Max 10 characters.")	
	      print "the package tag = %s" % packageTag
	    else:
	      raise Exception("the packageTag has not been specified")	
	  elif clinesplit[0] == "startTimeUTC":
	    if len(clinesplit) == 2:
	      if clinesplit[1].rstrip() != '':
		startTimeUTC = clinesplit[1].rstrip()
		startTime = datetime.strptime(startTimeUTC, '%Y-%m-%d %H:%M:%S')
		print "the start time (UTC) = %s" % startTime.strftime('%b %d %Y %H:%M:%S')
		set_starttime = True
	  elif clinesplit[0] == "timeStep1":
	    if len(clinesplit) == 2:
	      if clinesplit[1].rstrip() != '':
		timeStep1 = int(clinesplit[1].rstrip())
		print "the time step1 = %s seconds" % timeStep1
	  elif clinesplit[0] == "timeStep2":
	    if len(clinesplit) == 2:
	      if clinesplit[1].rstrip() != '':
		timeStep2 = int(clinesplit[1].rstrip())
		print "the time step2 = %s seconds" % timeStep2
	  elif clinesplit[0] == "stationList":
	    if len(clinesplit) == 2:
	      stationList = clinesplit[1].rstrip()
	      print "the used stations are %s" % stationList
	    else:
	      raise Exception("the stationList has not been specified")
	  elif clinesplit[0] == "create_calibrator_observations":
	    if mode == 1:
	      create_calibrator_observations = True
	    else: #if mode == 2:
	      if len(clinesplit) == 2:
		create_calibrator = clinesplit[1].rstrip()
		if create_calibrator in ['y','Y','YES','yes','t','T','True','true']:
		  create_calibrator_observations = True
		  print "calibrator observations will be created"
		else:
		  create_calibrator_observations = False
		  print "calibrator observations will not be created"
	      else:
		raise Exception("create_calibrator_observations has not been specified")
	  elif clinesplit[0] == "create_target_cal_beam":
	    if mode != 2: #if mode == 2:
	      if len(clinesplit) == 2:
		create_calibrator_beam = clinesplit[1].rstrip()
		if create_calibrator_beam in ['y','Y','YES','yes','t','T','True','true']:
		  create_target_cal_beam = True
		  print "a calibration beam will be generated in the target observation"
		else:
		  create_target_cal_beam = False
		  print "no calibration beam will be generated in the target observation"
	      else:
		raise Exception("create_target_cal_beam has not been specified")	  

	  elif clinesplit[0] == "create_extra_ncp_beam":
	    if len(clinesplit) == 2:
	      create_extra_ncp_beam = clinesplit[1].rstrip()
	      if create_extra_ncp_beam in ['y','Y','YES','yes','t','T','True','true']:
		create_extra_ncp_beam = True
		print "extra polarization beam will be created"
	      else:
		create_extra_ncp_beam = False
		print "extra polarization beam will not be created"
	    else:
	      raise Exception("create_extra_ncp_beam has not been specified")	  
	  elif clinesplit[0] == "antennaMode":
	    if len(clinesplit) == 2:
	      antennaMode = clinesplit[1].rstrip()
	      print "the used antennaMode = %s" % antennaMode
	    else:
	      raise Exception("the antennaMode has not been specified")	  
	  elif clinesplit[0] == "clock":
	    if len(clinesplit) == 2:
	      clock = clinesplit[1].rstrip()
	      print "the used clock = %s" % clock
	    else:
	      raise Exception("the clock mode has not been specified")	  
	  elif clinesplit[0] == "instrumentFilter":
	    if len(clinesplit) == 2:
	      instrumentFilter = clinesplit[1].rstrip()
	      print "the used instrumentFilter = %s" % instrumentFilter
	    else:
	      raise Exception("the instrumentFilter has not been specified")	  
	  elif clinesplit[0] == "integrationTime":
	    if len(clinesplit) == 2:
	      integrationTime = clinesplit[1].rstrip()
	      print "the used integrationTime = %s" % integrationTime
	    else:
	      raise Exception("the integrationTime has not been specified")	  
	  elif clinesplit[0] == "calibratorDurationSeconds":
	    if len(clinesplit) == 2:
	      calibratorDurationSeconds = int(clinesplit[1].rstrip())
	      print "the calibratorDurationSeconds = %s" % calibratorDurationSeconds
	    else:
	      raise Exception("the calibratorDurationSeconds has not been specified")
	  elif clinesplit[0] == "targetDurationSeconds":
	    if len(clinesplit) == 2:
	      targetDurationSeconds = int(clinesplit[1].rstrip())
	      print "the targetDurationSeconds = %s" % targetDurationSeconds
	    else:
	      raise Exception("the targetDurationSeconds has not been specified")
	  elif clinesplit[0] == "numberOfBitsPerSample":
	    if len(clinesplit) == 2:
	      numberOfBitsPerSample = int(clinesplit[1].rstrip())
	      print "the used numberOfBitsPerSample = %s" % numberOfBitsPerSample
	    else:
	      raise Exception("the numberOfBitsPerSample has not been specified")
	  elif clinesplit[0] == "channelsPerSubband":
	    if len(clinesplit) == 2:
	      channelsPerSubband = clinesplit[1].rstrip()
	      print "the used channelsPerSubband = %s" % channelsPerSubband
	    else:
	      raise Exception("the channelsPerSubband has not been specified")
	  elif clinesplit[0] == "nrSubbandsPerImage":
	    if len(clinesplit) == 2:
	      nrSubbandsPerImage = int(clinesplit[1].rstrip())
	      print "the nrSubbandsPerImage = %s" % nrSubbandsPerImage
	    else:
	      raise Exception("the nrSubbandsPerImage has not been specified")
	  elif clinesplit[0] == "skyModel":
	    if len(clinesplit) == 2:
	      skyModel = clinesplit[1].rstrip()
	      print "the skyModel = %s" % skyModel
	    else:
	      raise Exception("the skyModel has not been specified")
	  elif clinesplit[0] == "tbbPiggybackAllowed":
	    if len(clinesplit) == 2:
	      tbbPiggybackAllowed = clinesplit[1].rstrip()
	      print "tbbPiggybackAllowed = %s" % tbbPiggybackAllowed
	    else:
	      raise Exception("tbbPiggybackAllowed has not been specified")
	  elif clinesplit[0] == "calibratorBeam":
	    print "found the calibrator beams"
	    lineNr += 1
	    if lineNr >= nr_lines:
	      raise Exception("the calibration beam is not specified")
	    if lines[lineNr][0].isdigit():
	      clinesplit = lines[lineNr].split(';')
	      if len(clinesplit) == 12:
		if clinesplit[5] in ['y','Y','YES','yes','t','T','True','true']:
		  create_calibrator_pipeline = True
		else:
		  create_calibrator_pipeline = False
		if clinesplit[6] in ['y','Y','YES','yes','t','T','True','true']:
		  do_demix = True
		else:
		  do_demix = False
		
		calibratorBeam = [clinesplit[0],clinesplit[1],clinesplit[2],clinesplit[3],clinesplit[4],create_calibrator_pipeline,do_demix,clinesplit[7],clinesplit[8],clinesplit[9],clinesplit[10],clinesplit[11].rstrip()]
		print ("right ascenscion:" + calibratorBeam[0] + " declination:" + calibratorBeam[1] + " target:" + calibratorBeam[2] + " subbands:" + calibratorBeam[3] + " nrSubbands:" + calibratorBeam[4] 
		+ " create pipeline:" + str(calibratorBeam[5]) + " do_demix:" + str(calibratorBeam[6]) + " avg. freq step:" + calibratorBeam[7] + " avg. time step:" + calibratorBeam[8] + " demix freq step:" + calibratorBeam[9] 
		+ " demix time step:" + calibratorBeam[10] + " calibratorSource:" + calibratorBeam[11].rstrip())
		
		subbandListCalculated = parse_subband_list(calibratorBeam[3])
		calcNrSubbands = len(subbandListCalculated)
		if calcNrSubbands != int(calibratorBeam[4]):
		  raise Exception("The calculated number of subbands (" + str(calcNrSubbands) + ") is not equal to the specified number of subbands (" + calibratorBeam[4] + ")\nIs the subband list correct?: " + calibratorBeam[3])
		
		if int(calibratorBeam[9]) % int(calibratorBeam[7]) <> 0:
		  raise Exception("demixFreqStep (" + calibratorBeam[9] + ") should be integer multiple of averagingFreqStep (" + calibratorBeam[7] + ")")
		
	      else:
		raise Exception("not enough parameters for calibrator beam: " + lines[lineNr])
	    else:
	      raise Exception("the calibration beam is not (properly) specified (should start with the right ascenscion)")
	  elif clinesplit[0] == 'targetBeams':
	    print 'found the target beams'
	    lineNr += 1
	    if lineNr >= nr_lines:
	      raise Exception("no target beams have been specified")
	    while lines[lineNr][0].isdigit():
	      clinesplit = lines[lineNr].split(';')
	      if len(clinesplit) == 12:
		if clinesplit[5] in ['y','Y','YES','yes','t','T','True','true']:
		  create_pipeline = True
		else:
		  create_pipeline = False
		if clinesplit[6] in ['y','Y','YES','yes','t','T','True','true']:
		  do_demix = True
		else:
		  do_demix = False
		targetBeams.append([clinesplit[0],clinesplit[1],clinesplit[2],clinesplit[3],clinesplit[4],create_pipeline,do_demix,clinesplit[7],clinesplit[8],clinesplit[9],clinesplit[10],clinesplit[11].rstrip()])
		print ("right ascenscion:" + clinesplit[0] + " declination:" + clinesplit[1] + " target:" + clinesplit[2] + " subbands:" + clinesplit[3] + " nrSubbands:" + clinesplit[4] 
		+ " create pipeline:" + str(create_pipeline) + " do_demix:" + str(do_demix) + " avg. freq step:" + clinesplit[7] + " avg. time step:" + clinesplit[8] + " demix freq step:" + clinesplit[9] 
		+ " demix time step:" + clinesplit[10] + " skyModel:" + clinesplit[11].rstrip())
		
		subbandListCalculated = parse_subband_list(targetBeams[nr_beams][3])
		calcNrSubbands = len(subbandListCalculated)
		if calcNrSubbands != int(targetBeams[nr_beams][4]):
		  raise Exception("The calculated number of subbands (" + str(calcNrSubbands) + ") is not equal to the specified number of subbands (" + targetBeams[nr_beams][4] + ")\nIs the subband list correct?: " + targetBeams[nr_beams][3])
		
		if int(targetBeams[nr_beams][9]) % int(targetBeams[nr_beams][7]) <> 0:
		  raise Exception("demixFreqStep (" + targetBeams[nr_beams][9] + ") should be integer multiple of averagingFreqStep (" + targetBeams[nr_beams][7] + "), target beam:" + str(nr_beams))
		nr_beams += 1

	      else:
		raise Exception("not enough parameters for beam: " + lines[lineNr])
	      lineNr += 1
	      if lineNr >= nr_lines:
		break
	  elif clinesplit[0] == "number_of_slices":
	    if len(clinesplit) == 2:
	      nrSlices = int(clinesplit[1])
	      print "the number of slices = %s" % nrSlices
	    else:
	      raise Exception("the number of slices has not been specified for BLOCK:" + str(blockNr))
    
      ifile.close()
      
      if nr_beams == 0:
	raise Exception("no target beams have been specified for BLOCK:" + str(blockNr))
	exit(1)
	
	
      if nrSlices == 0:
	raise Exception("the number_of_slices is not specified for BLOCK:" + str(blockNr))
	exit(1)
      if packageName == '':
	raise Exception("the packageName is not specified for BLOCK:" + str(blockNr))
	exit(1)
      if stationList == '':
	raise Exception("the stationList is not specified for BLOCK:" + str(blockNr))
	exit(1)
      if antennaMode == '':
	raise Exception("the antennaMode is not specified for BLOCK:" + str(blockNr))
	exit(1)
      if instrumentFilter == '':
	raise Exception("the instrumentFilter is not specified for BLOCK:" + str(blockNr))
	exit(1)
      if integrationTime == '':
	raise Exception("the integrationTime is not specified for BLOCK:" + str(blockNr))
	exit(1)
      if (calibratorDurationSeconds == 0) and (create_calibrator_observations == True or mode == 1):
	raise Exception("the calibratorDurationSeconds is not specified for BLOCK:" + str(blockNr))
	exit(1)
      if (targetDurationSeconds == 0):
	raise Exception("the targetDurationSeconds is not specified for BLOCK:" + str(blockNr))
	exit(1)
      if numberOfBitsPerSample == 0:
	raise Exception("the numberOfBitsPerSample is not specified for BLOCK:" + str(blockNr))
	exit(1)
      if channelsPerSubband == 0:
	raise Exception("the channelsPerSubband is not specified for BLOCK:" + str(blockNr))
	exit(1)
      if (mode == 1 or mode == 2) and (nrSubbandsPerImage == 0):
	raise Exception("the nrSubbandsPerImage is not specified for BLOCK:" + str(blockNr))
	exit(1)

      if len(packageTag) == 0:
	writePackageTag = True
      else:
	writePackageTag = False
	
      if len(mainFolderName) == 0:
	createMainFolder = False
      else:
	createMainFolder = True
      
      if mode == 1:
	#do_export_solutions = True
	do_imaging = True
      elif mode == 2:
	#do_export_solutions = False
	create_target_cal_beam = True
	do_imaging = True
      elif mode == 3:
	#do_export_solutions = True
	do_imaging = False
      elif mode == 4:
	#do_export_solutions = True
	do_imaging = False
      
      
      if first_block:
	first_block = False
	print >>ofile, r"""<?xml version="1.0" encoding="UTF-8"?>
	<lofar:project xmlns:lofar="http://www.astron.nl/MoM2-Lofar" xmlns:mom2="http://www.astron.nl/MoM2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.astron.nl/MoM2-Lofar http://lofar.astron.nl:8080/mom3/schemas/LofarMoM2.xsd http://www.astron.nl/MoM2 http://lofar.astron.nl:8080/mom3/schemas/MoM2.xsd ">
	<template version="1.2 (10 jan 2013)" author="Alwin de Jong" changedBy="Alwin de Jong">
	<description>Cycle_0 XML Template generator version 9</description>
	</template>
	<name>%s</name>
	<children>""" % projectName
	if createMainFolder:
	  print >>ofile, r"""	  <item index="0">
	    <lofar:folder topology_parent="false">
	    <name>%s</name>
	    <description>%s</description>
	    <children>""" % (mainFolderName, mainFolderDescription)

	
      if do_imaging:
	nrImages = []
	for i in range(0, nr_beams):
	  if int(targetBeams[i][4]) % nrSubbandsPerImage <> 0:
	    raise Exception("nrSubbands (" + targetBeams[i][4] + ") should be integer dividable by the nrSubbandsPerImage (" + str(nrSubbandsPerImage) + ") for target beam " + str(i))
	  nrImages.append(int(targetBeams[i][4]) / nrSubbandsPerImage)

      
      print >>ofile, r"""	  <item index="0">
	    <lofar:folder topology_parent="true">
	      <topology>0</topology>
	      <name>%s</name>
	      <description>%s</description>
	      <children>""" % (packageName, mode_str + ':' + packageDescription)

      if set_starttime:
	startTimeObs = startTime

      
      if do_imaging:
	imaging_pipe_inputs = dict()
	imaging_pipe_predecessors = dict()
	for i in range(0, nr_beams):
	  imaging_pipe_inputs[i] = []
	  imaging_pipe_predecessors[i] = []
	
	#TODO: imaging pipeline default template should be choosen here, currently we always revert to the msss imaging pipeline template
	if antennaMode.startswith("HBA"):
	  imaging_pipe_default_template = "Imaging Pipeline"
	else:
	  imaging_pipe_default_template = "Imaging Pipeline"

      blockTopo = "B" + str(blockNr) + '.'
      for sliceNr in range (1, nrSlices+1):
	tar_obs_beam_topologies = []
	tar_obs_beam_data_topologies = []
	tar_pipe_topologies = []
	tar_pipe_output_data_topologies = []
	sliceStr = str(sliceNr)

	cal_obs_topology = blockTopo + sliceStr + '.C'               		# 1.C
	cal_obs_beam0_topology = cal_obs_topology + '.SAP000'  		# 1.C.SAP000
	cal_obs_beam_data_topo = cal_obs_beam0_topology + '.dps'		# 1.C.SAP000.dps
	tar_obs_topology = blockTopo + sliceStr + '.T'               		# 1.T
	cal_pipe_calibrator_topology = blockTopo + sliceStr + '.CPC'				# 1.Pn
	cal_pipe_calibrator_output_data_topo = cal_pipe_calibrator_topology + '.dps'		# 1.Pn.dps
	cal_pipe_target_topology = blockTopo + sliceStr + '.CPT'				# 1.Pn
	cal_pipe_target_output_data_topo = cal_pipe_target_topology + '.dps'		# 1.Pn.dps
	
	if mode == 1: # Calobs
	  cal_obs_pipe_default_template = "Calibrator Pipeline (export)"
	  cal_tar_pipe_default_template = "Calibrator Pipeline (no export)"
	  cal_pipe_calibrator_descriprion = "Cal Pipe Target"
	  cal_pipe_target_description = "Cal Pipe Target"
	  cal_pipe_target_output_data_type = "instrumentModelDataProduct"
	  tar_pipe_predecessor = tar_obs_topology + ',' + cal_pipe_calibrator_topology # 1.T,1.CPC
	  tar_pipe_input_inst_topo = cal_pipe_calibrator_output_data_topo		# 1.P1.dps
	elif mode == 2: # Calbeam
	  cal_obs_pipe_default_template = "Calibrator Pipeline (export)"
	  cal_tar_pipe_default_template = "Calibrator Pipeline (no export)"
	  cal_pipe_calibrator_descriprion = "Cal Pipe Target"
	  cal_pipe_target_description = "Cal Pipe Target"
	  cal_pipe_target_output_data_type = "instrumentModelDataProduct"
	  tar_pipe_predecessor = tar_obs_topology + ',' + cal_pipe_target_topology # 1.T,1.CPT
	  tar_pipe_input_inst_topo = cal_pipe_target_output_data_topo		# 1.P1.dps
	elif mode == 3:
	  tar_pipe_predecessor = tar_obs_topology # 1.T
	  tar_pipe_input_inst_topo = ''		# no input instrument models for these modes
	  cal_pipe_target_output_data_type = "uvDataProduct"
	  if calibratorBeam[6]: # do demix?
	    cal_obs_pipe_default_template = "Preprocess. Pipeline (demix)"
	    cal_tar_pipe_default_template = "Preprocess. Pipeline (demix)"
	    cal_pipe_calibrator_descriprion = "Preprocessing,demixing"
	    cal_pipe_target_description = "Preprocessing,demixing"
	  else:
	    cal_obs_pipe_default_template = "Preprocess. Pipeline (no demix)"
	    cal_tar_pipe_default_template = "Preprocess. Pipeline (no demix)"
	    cal_pipe_calibrator_descriprion = "Preprocessing,averaging"
	    cal_pipe_target_description = "Preprocessing,averaging"
	elif mode == 4:
	  tar_pipe_predecessor = tar_obs_topology # 1.T
	  tar_pipe_input_inst_topo = ''		# no input instrument models for these modes
	  cal_pipe_target_output_data_type = "uvDataProduct"
	  if calibratorBeam[6]: # do demix?
	    cal_obs_pipe_default_template = "Calibration Pipeline (demix)"
	    cal_tar_pipe_default_template = "Calibration Pipeline (demix)"
	    cal_pipe_calibrator_descriprion = "Calibration,averaging"
	    cal_pipe_target_description = "Calibration,demixing"
	  else:
	    cal_obs_pipe_default_template = "Calibration Pipeline (no demix)"
	    cal_tar_pipe_default_template = "Calibration Pipeline (no demix)"
	    cal_pipe_calibrator_descriprion = "Calibration,averaging"
	    cal_pipe_target_description = "Calibration,averaging"
	    
	for beamNr in range (0, nr_beams):
	  beam_nr_str = str(beamNr)
	  if create_calibrator_observations:
	    if writePackageTag:
	      cal_obs_name = calibratorBeam[2] + "/" + sliceStr + "/CO"
	    else:
	      cal_obs_name = packageTag + "/" + calibratorBeam[2] + "/" + sliceStr + "/CO"
	  
	  tar_obs_beam_topologies.append(tar_obs_topology + ".SAP" + beam_nr_str.rjust(3,'0'))
	  tar_obs_beam_data_topologies.append(tar_obs_beam_topologies[beamNr] + ".dps")
	      
	  tar_pipe_topologies.append(blockTopo + sliceStr + ".PT" + beam_nr_str)
	  tar_pipe_output_data_topologies.append(tar_pipe_topologies[beamNr] + ".dps")
	  if do_imaging:
	    imaging_pipe_inputs[beamNr].append(tar_pipe_output_data_topologies[beamNr])
	    imaging_pipe_predecessors[beamNr].append(tar_pipe_topologies[beamNr])

	if create_extra_ncp_beam:
	  tarObsCalBeamDataTopoStr = tar_obs_topology + ".SAP" + str(nr_beams+1).rjust(3,'0') + ".dps"
	else:
	  tarObsCalBeamDataTopoStr = tar_obs_topology + ".SAP" + str(nr_beams).rjust(3,'0') + ".dps"
	tar_obs_beam_data_topologies.append(tarObsCalBeamDataTopoStr)
	    
	tar_obs_predecessor = ''
	if create_calibrator_observations:
	  tar_obs_predecessor = cal_obs_topology			# 1.C
	  if set_starttime:
	    startTimeStr = startTimeObs.strftime('%Y-%m-%dT%H:%M:%S')
	    endTimeStr = (startTimeObs + timedelta(seconds=calibratorDurationSeconds)).strftime('%Y-%m-%dT%H:%M:%S')
	  else:
	    startTimeStr = ''
	    endTimeStr = ''
	    
	  print >>ofile, r"""          <item index="0">
	      <lofar:observation>
		<name>%s</name>
		<description>%s (Calibration Observation)</description>
		<topology>%s</topology>
		<currentStatus>
		  <mom2:openedStatus/>
		</currentStatus>
		<lofar:observationAttributes>
		  <observationId>
		  </observationId>
		  <name>%s</name>
		  <projectName>%s</projectName>
		  <instrument>Interferometer</instrument>
		  <defaultTemplate>Interferometer</defaultTemplate>
		  <tbbPiggybackAllowed>%s</tbbPiggybackAllowed>
		  <userSpecification>
		    <correlatedData>true</correlatedData>
		    <filteredData>false</filteredData>
		    <beamformedData>false</beamformedData>
		    <coherentStokesData>false</coherentStokesData>
		    <incoherentStokesData>false</incoherentStokesData>
		    <antenna>%s</antenna>
		    <clock mode="%s"/>
		    <instrumentFilter>%s</instrumentFilter>
		    <integrationInterval>%s</integrationInterval>
		    <channelsPerSubband>%s</channelsPerSubband>
		    <coherentDedisperseChannels>false</coherentDedisperseChannels>
		    <stokes>
		      <integrateChannels>false</integrateChannels>
		    </stokes>
		    <stationSet>Custom</stationSet>
		    <stations>%s</stations>
		    <timeFrame>UT</timeFrame>
		    <startTime>%s</startTime>
		    <endTime>%s</endTime>
		    <duration>%s</duration>
		    <bypassPff>false</bypassPff>
		    <enableSuperterp>false</enableSuperterp>
		    <numberOfBitsPerSample>%s</numberOfBitsPerSample>
		  </userSpecification>
		</lofar:observationAttributes>
		
		<children>
		  <item index="0">
		    <lofar:measurement xsi:type="lofar:UVMeasurementType">
		      <name>%s</name>
		      <description>%s</description>
		      <topology>%s</topology>
		      <currentStatus>
			<mom2:openedStatus/>
		      </currentStatus>
		      <lofar:uvMeasurementAttributes>
			<measurementType>Calibration</measurementType>
			<specification>
			  <targetName>%s</targetName>
			  <ra>%s</ra>
			  <dec>%s</dec>
			  <equinox>J2000</equinox>
			  <duration>0</duration>
			  <subbandsSpecification>
			    <bandWidth unit="MHz">48</bandWidth>
			    <centralFrequency unit="MHz">150</centralFrequency>
			    <contiguous>true</contiguous>
			    <subbands>%s</subbands>
			  </subbandsSpecification>
			</specification>
		      </lofar:uvMeasurementAttributes>
		      <resultDataProducts>
			<item>
			  <lofar:uvDataProduct>
			    <name>%s</name>
			    <topology>%s</topology>
			    <status>no_data</status>
			  </lofar:uvDataProduct>
			</item>	
		      </resultDataProducts>	
		    </lofar:measurement>
		  </item>
		</children>
	      </lofar:observation>
	    </item>""" % (
	    
	    # ****** CALIBRATOR OBSERVATION ******
	    cal_obs_name, 			# <name>Calibrator %s</name>
	    cal_obs_name, 			# <description>Calibrator observation %s</description>
	    cal_obs_topology,		# <topology>%s</topology>
	    cal_obs_name,			# <name>Calibrator %s</name>
	    projectName,
	    tbbPiggybackAllowed,
	    antennaMode,
	    clock,
	    instrumentFilter,
	    integrationTime,
	    channelsPerSubband,
	    stationList,
	    startTimeStr,
	    endTimeStr,
	    calibratorDurationSeconds,
	    numberOfBitsPerSample,
	    calibratorBeam[2],
	    calibratorBeam[2],
	    cal_obs_beam0_topology, 	# <topology>%s</topology> (beam topo)
	    calibratorBeam[2],
	    calibratorBeam[0],
	    calibratorBeam[1],
	    calibratorBeam[3],
	    cal_obs_beam_data_topo, 	# <name>%s</name> (calibrator beam data product name)
	    cal_obs_beam_data_topo, 	# <topology>%s</topology> (calibrator beam data product topology)
	    )

	    
	# target start and end time:
	if set_starttime:
	  if create_calibrator_observations:
	    startTimeObs = startTimeObs + timedelta(seconds=timeStep1+calibratorDurationSeconds)
	  startTimeStr = startTimeObs.strftime('%Y-%m-%dT%H:%M:%S')
	  endTimeStr = (startTimeObs + timedelta(seconds=targetDurationSeconds)).strftime('%Y-%m-%dT%H:%M:%S')
	else:
	  startTimeStr = ''
	  endTimeStr = ''

	if create_calibrator_observations and create_calibrator_pipeline:
	  if writePackageTag:
	    cal_pipe_name = calibratorBeam[2] + "/" + sliceStr + "/CPC"
	  else:
	    cal_pipe_name = packageTag + "/" + calibratorBeam[2] + "/" + sliceStr + "/CPC"
	  if mode == 1 or mode == 2:
	    print >> ofile, r"""	  <item index="0">
	    <lofar:pipeline xsi:type="lofar:CalibrationPipelineType">
	      <topology>%s</topology>
	      <predecessor_topology>%s</predecessor_topology>
	      <name>%s</name>children
	      <description>%s (%s)</description>
	      <calibrationPipelineAttributes>
		<defaultTemplate>%s</defaultTemplate>
		<frequencyIntegrationStep>%s</frequencyIntegrationStep>
		<timeIntegrationStep>%s</timeIntegrationStep>
		<demixFreqStep>%s</demixFreqStep>
		<demixTimeStep>%s</demixTimeStep>
		<flagAutocorrelations>true</flagAutocorrelations>
		<skyModelDatabase></skyModelDatabase>
		<demixing>%s</demixing>
		<calibratorSource>%s</calibratorSource>
		<nrOfOutputInstrumentModel>%s</nrOfOutputInstrumentModel>
	      </calibrationPipelineAttributes>
	      <usedDataProducts>
		<item>
		  <lofar:uvDataProduct topology="%s">
		  </lofar:uvDataProduct>
		</item>
	      </usedDataProducts>
	      <resultDataProducts>
		<item>
		  <lofar:instrumentModelDataProduct>
		    <name>%s</name>
		    <topology>%s</topology>
		    <status>no_data</status>
		  </lofar:instrumentModelDataProduct>
		</item>
	      </resultDataProducts>
	    </lofar:pipeline>
	  </item>""" % (
	  # ****** CALIBRATION PIPELINE ******
	  cal_pipe_calibrator_topology,		# <topology>%s</topology>
	  cal_obs_topology,		# <predecessor_topology>%s</predecessor_topology>
	  cal_pipe_name,			# <name>Calibration Pipeline %s</name>
	  cal_pipe_name,cal_pipe_calibrator_descriprion,	# <description>Calibration Pipeline %s</description>
	  cal_obs_pipe_default_template,	# <defaultTemplate>%s</defaultTemplate>
	  calibratorBeam[7],		# <frequencyIntegrationStep>%s</frequencyIntegrationStep>
	  calibratorBeam[8],		# <timeIntegrationStep>%s</timeIntegrationStep>
	  calibratorBeam[9],		# <demixFreqStep>%s</demixFreqStep>
	  calibratorBeam[10],		# <demixTimeStep>%s</demixTimeStep>
	  str(calibratorBeam[6]).lower(), # <demixing>
	  calibratorBeam[11],		# <calibratorSource>%s</calibratorSource>
	  calibratorBeam[4],		# <nrOfOutputInstrumentModel>%s</nrOfOutputInstrumentModel>
	  cal_obs_beam_data_topo,	# <lofar:uvDataProduct topology="%s">
	  cal_pipe_calibrator_output_data_topo,	# <name>%s</name>
	  cal_pipe_calibrator_output_data_topo,	# <topology>%s</topology>
	  )
	  elif mode == 3:
	    print >> ofile, r"""	  <item index="0">
	    <lofar:pipeline xsi:type="lofar:AveragingPipelineType">
	      <topology>%s</topology>
	      <predecessor_topology>%s</predecessor_topology>
	      <name>%s</name>children
	      <description>%s (%s)</description>
	      <averagingPipelineAttributes>
		<defaultTemplate>%s</defaultTemplate>
		<frequencyIntegrationStep>%s</frequencyIntegrationStep>
		<timeIntegrationStep>%s</timeIntegrationStep>
		<demixFreqStep>%s</demixFreqStep>
		<demixTimeStep>%s</demixTimeStep>
		<flagAutocorrelations>true</flagAutocorrelations>
		<skyModelDatabase></skyModelDatabase>
		<demixing>%s</demixing>
		<calibratorSource>%s</calibratorSource>
		<nrOfOutputCorrelated>%s</nrOfOutputCorrelated>
	      </averagingPipelineAttributes>
	      <usedDataProducts>
		<item>
		  <lofar:uvDataProduct topology="%s">
		  </lofar:uvDataProduct>
		</item>
	      </usedDataProducts>
	      <resultDataProducts>
		<item>
		  <lofar:uvDataProduct>
		    <name>%s</name>
		    <topology>%s</topology>
		    <status>no_data</status>
		  </lofar:uvDataProduct>
		</item>
	      </resultDataProducts>
	    </lofar:pipeline>
	  </item>""" % (
	  # ****** CALIBRATION PIPELINE ******
	  cal_pipe_calibrator_topology,		# <topology>%s</topology>
	  cal_obs_topology,		# <predecessor_topology>%s</predecessor_topology>
	  cal_pipe_name,			# <name>Calibration Pipeline %s</name>
	  cal_pipe_name,cal_pipe_calibrator_descriprion,	# <description>Calibration Pipeline %s</description>
	  cal_obs_pipe_default_template,	# <defaultTemplate>%s</defaultTemplate>
	  calibratorBeam[7],		# <frequencyIntegrationStep>%s</frequencyIntegrationStep>
	  calibratorBeam[8],		# <timeIntegrationStep>%s</timeIntegrationStep>
	  calibratorBeam[9],		# <demixFreqStep>%s</demixFreqStep>
	  calibratorBeam[10],		# <demixTimeStep>%s</demixTimeStep>
	  str(calibratorBeam[6]).lower(), # <demixing>
	  calibratorBeam[11],		# <calibratorSource>%s</calibratorSource>
	  calibratorBeam[4],		# <nrOfOutputInstrumentModel>%s</nrOfOutputInstrumentModel>
	  cal_obs_beam_data_topo,	# <lofar:uvDataProduct topology="%s">
	  cal_pipe_calibrator_output_data_topo,	# <name>%s</name>
	  cal_pipe_calibrator_output_data_topo,	# <topology>%s</topology>
	  )
	  elif mode == 4:
	    print >> ofile, r"""	  <item index="0">
	    <lofar:pipeline xsi:type="lofar:CalibrationPipelineType">
	      <topology>%s</topology>
	      <predecessor_topology>%s</predecessor_topology>
	      <name>%s</name>children
	      <description>%s (%s)</description>
	      <calibrationPipelineAttributes>
		<defaultTemplate>%s</defaultTemplate>
		<frequencyIntegrationStep>%s</frequencyIntegrationStep>
		<timeIntegrationStep>%s</timeIntegrationStep>
		<demixFreqStep>%s</demixFreqStep>
		<demixTimeStep>%s</demixTimeStep>
		<flagAutocorrelations>true</flagAutocorrelations>
		<skyModelDatabase>%s</skyModelDatabase>
		<demixing>%s</demixing>
		<calibratorSource></calibratorSource>
		<nrOfOutputCorrelated>%s</nrOfOutputCorrelated>
	      </calibrationPipelineAttributes>
	      <usedDataProducts>
		<item>
		  <lofar:uvDataProduct topology="%s">
		  </lofar:uvDataProduct>
		</item>
	      </usedDataProducts>
	      <resultDataProducts>
		<item>
		  <lofar:uvDataProduct>
		    <name>%s</name>
		    <topology>%s</topology>
		    <status>no_data</status>
		  </lofar:uvDataProduct>
		</item>
	      </resultDataProducts>
	    </lofar:pipeline>
	  </item>""" % (
	  # ****** CALIBRATION PIPELINE ******
	  cal_pipe_calibrator_topology,		# <topology>%s</topology>
	  cal_obs_topology,		# <predecessor_topology>%s</predecessor_topology>
	  cal_pipe_name,			# <name>Calibration Pipeline %s</name>
	  cal_pipe_name,cal_pipe_calibrator_descriprion,	# <description>Calibration Pipeline %s</description>
	  cal_obs_pipe_default_template,	# <defaultTemplate>%s</defaultTemplate>
	  calibratorBeam[7],		# <frequencyIntegrationStep>%s</frequencyIntegrationStep>
	  calibratorBeam[8],		# <timeIntegrationStep>%s</timeIntegrationStep>
	  calibratorBeam[9],		# <demixFreqStep>%s</demixFreqStep>
	  calibratorBeam[10],		# <demixTimeStep>%s</demixTimeStep>
	  calibratorBeam[11],		# <skyModelDatabase>%s</skyModelDatabase>
	  str(calibratorBeam[6]).lower(), # <demixing>
	  calibratorBeam[4],		# <nrOfOutputInstrumentModel>%s</nrOfOutputInstrumentModel>
	  cal_obs_beam_data_topo,	# <lofar:uvDataProduct topology="%s">
	  cal_pipe_calibrator_output_data_topo,	# <name>%s</name>
	  cal_pipe_calibrator_output_data_topo,	# <topology>%s</topology>
	  )

	if writePackageTag:
	  tar_obs_name = targetBeams[0][2] + "/" + sliceStr + "/TO"
	else:
	  tar_obs_name = packageTag + "/" + targetBeams[0][2] + "/" + sliceStr + "/TO"
	  
	print >> ofile, r"""<item index="0">
	<lofar:observation>
	  <name>%s</name>
	  <description>%s (Target Observation)</description>
	  <topology>%s</topology>
	    <predecessor_topology>%s</predecessor_topology>
	    <currentStatus>
	      <mom2:openedStatus/>
	    </currentStatus>
	    <lofar:observationAttributes>
	      <observationId>
	      </observationId>
	      <name>%s</name>
	      <projectName>%s</projectName>
	      <instrument>Interferometer</instrument>
	      <defaultTemplate>Interferometer</defaultTemplate>
	      <tbbPiggybackAllowed>%s</tbbPiggybackAllowed>
	      <userSpecification>
		<correlatedData>true</correlatedData>
		<filteredData>false</filteredData>
		<beamformedData>false</beamformedData>
		<coherentStokesData>false</coherentStokesData>
		<incoherentStokesData>false</incoherentStokesData>
		<antenna>%s</antenna>
		<clock mode="%s"/>
		<instrumentFilter>%s</instrumentFilter>
		<integrationInterval>%s</integrationInterval>
		<channelsPerSubband>%s</channelsPerSubband>
		<coherentDedisperseChannels>false</coherentDedisperseChannels>
		<stokes>
		  <integrateChannels>false</integrateChannels>
		</stokes>
		<stationSet>Custom</stationSet>
		<stations>%s</stations>
		<timeFrame>UT</timeFrame>
		<startTime>%s</startTime>
		<endTime>%s</endTime>
		<duration>%s</duration>
		<bypassPff>false</bypassPff>
		<enableSuperterp>false</enableSuperterp>
		<numberOfBitsPerSample>%s</numberOfBitsPerSample>
	      </userSpecification>
	    </lofar:observationAttributes>
	    <children>""" % (
	      tar_obs_name,				# <name>Target Observation %s</name>
	      tar_obs_name, 				# <description>Target Observation %s</description>
	      tar_obs_topology,			# <topology>%s</topology>
	      tar_obs_predecessor,
	      tar_obs_name,
	      projectName,
	      tbbPiggybackAllowed,
	      antennaMode,
	      clock,
	      instrumentFilter,
	      integrationTime,
	      channelsPerSubband,
	      stationList,
	      startTimeStr,
	      endTimeStr,
	      targetDurationSeconds,
	      numberOfBitsPerSample
	    )
	  
	if set_starttime:
	  if create_calibrator_observations:
	    startTimeObs = startTimeObs + timedelta(seconds=timeStep2+targetDurationSeconds)
	  else:
	    startTimeObs = startTimeObs + timedelta(seconds=timeStep1+targetDurationSeconds)
	      
	for beamNr in range(0, nr_beams):
	  print >> ofile, r"""<item index="0">
		<lofar:measurement xsi:type="lofar:UVMeasurementType">
		  <name>%s</name>
		  <description>%s</description>
		  <topology>%s</topology>
		  <currentStatus>
		    <mom2:openedStatus/>
		  </currentStatus>
		  <lofar:uvMeasurementAttributes>
		    <measurementType>Target</measurementType>
		    <specification>
		      <targetName>%s</targetName>
		      <ra>%s</ra>
		      <dec>%s</dec>
		      <equinox>J2000</equinox>
		      <duration>0</duration>
		      <subbandsSpecification>
			<bandWidth unit="MHz">48</bandWidth>
			<centralFrequency unit="MHz">150</centralFrequency>
			<contiguous>true</contiguous>
			<subbands>%s</subbands>
		      </subbandsSpecification>
		    </specification>
		  </lofar:uvMeasurementAttributes>
		  <resultDataProducts>
		    <item>
		      <lofar:uvDataProduct>
			<name>%s</name>
			<topology>%s</topology>
			<status>no_data</status>
		      </lofar:uvDataProduct>
		    </item>	
		  </resultDataProducts>	
		</lofar:measurement>
	      </item>"""% (
	    targetBeams[beamNr][2],		# <name>%s</name>
	    targetBeams[beamNr][2],		# <description>%s</description>
	    tar_obs_beam_topologies[beamNr],	# <topology>%s</topology>
	    targetBeams[beamNr][2],
	    targetBeams[beamNr][0],
	    targetBeams[beamNr][1],
	    targetBeams[beamNr][3],
	    tar_obs_beam_data_topologies[beamNr],	# <name>%s</name> (target beam0 data product name)
	    tar_obs_beam_data_topologies[beamNr],	# <topology>%s</topology> (target beam0 data product topology)
	    )

	# create the extra polarization beam?
	if create_extra_ncp_beam:
	  polBeamTopo = tar_obs_topology + ".SAP" + str(beamNr+1).rjust(3,'0')
	  polBeamDataTopo = polBeamTopo + '.dps'
	  print >> ofile, r"""<item index="0">
	    <lofar:measurement xsi:type="lofar:UVMeasurementType">
	      <name>%s (+90 dec)</name>
	      <description>%s (+90 declination)</description>
	      <topology>%s</topology>
	      <currentStatus>
		<mom2:openedStatus/>
	      </currentStatus>
	      <lofar:uvMeasurementAttributes>
		<measurementType>Calibration</measurementType>
		<specification>
		  <targetName>%s (+90 dec)</targetName>
		  <ra>%s</ra>
		  <dec>90.0</dec>
		  <equinox>J2000</equinox>
		  <duration>0</duration>
		  <subbandsSpecification>
		    <bandWidth unit="MHz">48</bandWidth>
		    <centralFrequency unit="MHz">150</centralFrequency>
		    <contiguous>true</contiguous>
		    <subbands>308</subbands>
		  </subbandsSpecification>
		</specification>
	      </lofar:uvMeasurementAttributes>
	      <resultDataProducts>
		<item>
		  <lofar:uvDataProduct>
		    <name>%s</name>
		    <topology>%s</topology>
		    <status>no_data</status>
		  </lofar:uvDataProduct>
		</item>	
	      </resultDataProducts>	
	    </lofar:measurement>
	  </item>""" % (
	  targetBeams[0][2],
	  targetBeams[0][2],		# <description>%s</description>
	  polBeamTopo, 	# <topology>%s</topology> (beam topo)
	  targetBeams[0][2],
	  targetBeams[0][0],
	  polBeamDataTopo, 	# <name>%s</name> (calibrator beam data product name)
	  polBeamDataTopo, 	# <topology>%s</topology> (calibrator beam data product topology)
	  )

	# create a calibrator beam in the target observation?
	if create_target_cal_beam:
	  if create_extra_ncp_beam:
	    calBeamTopo = tar_obs_topology + ".SAP" + str(beamNr+2).rjust(3,'0')
	  else:
	    calBeamTopo = tar_obs_topology + ".SAP" + str(beamNr+1).rjust(3,'0')
	  print >> ofile, r"""<item index="0">
		    <lofar:measurement xsi:type="lofar:UVMeasurementType">
		      <name>%s</name>
		      <description>%s</description>
		      <topology>%s</topology>
		      <currentStatus>
			<mom2:openedStatus/>
		      </currentStatus>
		      <lofar:uvMeasurementAttributes>
			<measurementType>Calibration</measurementType>
			<specification>
			  <targetName>%s</targetName>
			  <ra>%s</ra>
			  <dec>%s</dec>
			  <equinox>J2000</equinox>
			  <duration>0</duration>
			  <subbandsSpecification>
			    <bandWidth unit="MHz">48</bandWidth>
			    <centralFrequency unit="MHz">150</centralFrequency>
			    <contiguous>true</contiguous>
			    <subbands>%s</subbands>
			  </subbandsSpecification>
			</specification>
		      </lofar:uvMeasurementAttributes>
		      <resultDataProducts>
			<item>
			  <lofar:uvDataProduct>
			    <name>%s</name>
			    <topology>%s</topology>
			    <status>no_data</status>
			  </lofar:uvDataProduct>
			</item>	
		      </resultDataProducts>	
		    </lofar:measurement>
		  </item>""" % (
		  calibratorBeam[2],
		  calibratorBeam[2],
		  calBeamTopo, 	# <topology>%s</topology> (beam topo)
		  calibratorBeam[2],
		  calibratorBeam[0],
		  calibratorBeam[1],
		  calibratorBeam[3],
		  tar_obs_beam_data_topologies[nr_beams], 	# <name>%s</name> (calibrator beam data product name)
		  tar_obs_beam_data_topologies[nr_beams], 	# <topology>%s</topology> (calibrator beam data product topology)
		  )

	  print >> ofile, r"""</children>
	      </lofar:observation>
	      </item>"""

		  
	  if writePackageTag:
	    cal_pipe_target_name = calibratorBeam[2] + "/" + sliceStr + "/CPT"
	  else:
	    cal_pipe_target_name = packageTag + "/" + calibratorBeam[2] + "/" + sliceStr + "/CPT"
	  
	  create_pipeline = calibratorBeam[5]
	  if create_pipeline:
	    if mode == 1 or mode == 2:
	      print >> ofile, r"""
		<item index="0">
		  <lofar:pipeline xsi:type="lofar:CalibrationPipelineType">
		    <topology>%s</topology>
		    <predecessor_topology>%s</predecessor_topology>
		    <name>%s</name>children
		    <description>%s (%s)</description>
		    <calibrationPipelineAttributes>
		      <defaultTemplate>%s</defaultTemplate>
		      <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		      <timeIntegrationStep>%s</timeIntegrationStep>
		      <demixFreqStep>%s</demixFreqStep>
		      <demixTimeStep>%s</demixTimeStep>
		      <flagAutocorrelations>true</flagAutocorrelations>
		      <skyModelDatabase></skyModelDatabase>
		      <demixing>%s</demixing>
		      <calibratorSource>%s</calibratorSource>
		      <nrOfOutputInstrumentModel>%s</nrOfOutputInstrumentModel>
		    </calibrationPipelineAttributes>
		    <usedDataProducts>
		      <item>
			<lofar:uvDataProduct topology="%s">
			</lofar:uvDataProduct>
		      </item>
		    </usedDataProducts>
		    <resultDataProducts>
		      <item>
			<lofar:%s>
			  <name>%s</name>
			  <topology>%s</topology>
			  <status>no_data</status>
			</lofar:%s>
		      </item>
		    </resultDataProducts>
		  </lofar:pipeline>
		</item>""" % (
		# ****** CALIBRATION PIPELINE ******
		cal_pipe_target_topology,		# <topology>%s</topology>
		tar_obs_topology,		# <predecessor_topology>%s</predecessor_topology>
		cal_pipe_target_name,			# <name>Calibration Pipeline %s</name>
		cal_pipe_target_name,cal_pipe_target_description,	# <description>Calibration Pipeline %s</description>
		cal_tar_pipe_default_template, # <defaultTemplate>
		calibratorBeam[7],		# <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		calibratorBeam[8],		# <timeIntegrationStep>%s</timeIntegrationStep>
		calibratorBeam[9],		# <demixFreqStep>%s</demixFreqStep>
		calibratorBeam[10],		# <demixTimeStep>%s</demixTimeStep>
		str(calibratorBeam[6]).lower(),		# <demixing>
		calibratorBeam[11],		# <calibratorSource>%s</calibratorSource>
		calibratorBeam[4],		# <nrOfOutputInstrumentModel>%s</nrOfOutputInstrumentModel>
		tar_obs_beam_data_topologies[nr_beams],	# <lofar:uvDataProduct topology="%s">
		cal_pipe_target_output_data_type,
		cal_pipe_target_output_data_topo,	# <name>%s</name>
		cal_pipe_target_output_data_topo,	# <topology>%s</topology>
		cal_pipe_target_output_data_type,
		)
	    
	    elif mode == 3:
	      print >> ofile, r"""
		<item index="0">
		  <lofar:pipeline xsi:type="lofar:AveragingPipelineType">
		    <topology>%s</topology>
		    <predecessor_topology>%s</predecessor_topology>
		    <name>%s</name>children
		    <description>%s (%s)</description>
		    <averagingPipelineAttributes>
		      <defaultTemplate>%s</defaultTemplate>
		      <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		      <timeIntegrationStep>%s</timeIntegrationStep>
		      <demixFreqStep>%s</demixFreqStep>
		      <demixTimeStep>%s</demixTimeStep>
		      <flagAutocorrelations>true</flagAutocorrelations>
		      <demixing>%s</demixing>
		      <nrOfOutputCorrelated>%s</nrOfOutputCorrelated>
		    </averagingPipelineAttributes>
		    <usedDataProducts>
		      <item>
			<lofar:uvDataProduct topology="%s">
			</lofar:uvDataProduct>
		      </item>
		    </usedDataProducts>
		    <resultDataProducts>
		      <item>
			<lofar:%s>
			  <name>%s</name>
			  <topology>%s</topology>
			  <status>no_data</status>
			</lofar:%s>
		      </item>
		    </resultDataProducts>
		  </lofar:pipeline>
		</item>""" % (
		# ****** CALIBRATION PIPELINE ******
		cal_pipe_target_topology,		# <topology>%s</topology>
		tar_obs_topology,		# <predecessor_topology>%s</predecessor_topology>
		cal_pipe_target_name,			# <name>Calibration Pipeline %s</name>
		cal_pipe_target_name,cal_pipe_target_description,	# <description>Calibration Pipeline %s</description>
		cal_tar_pipe_default_template, # <defaultTemplate>
		calibratorBeam[7],		# <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		calibratorBeam[8],		# <timeIntegrationStep>%s</timeIntegrationStep>
		calibratorBeam[9],		# <demixFreqStep>%s</demixFreqStep>
		calibratorBeam[10],		# <demixTimeStep>%s</demixTimeStep>
		str(calibratorBeam[6]).lower(),		# <demixing>
		calibratorBeam[4],		# <nrOfOutputInstrumentModel>%s</nrOfOutputInstrumentModel>
		tar_obs_beam_data_topologies[nr_beams],	# <lofar:uvDataProduct topology="%s">
		cal_pipe_target_output_data_type,
		cal_pipe_target_output_data_topo,	# <name>%s</name>
		cal_pipe_target_output_data_topo,	# <topology>%s</topology>
		cal_pipe_target_output_data_type,
		)
	    
	    elif mode == 4:
	      print >> ofile, r"""
		<item index="0">
		  <lofar:pipeline xsi:type="lofar:CalibrationPipelineType">
		    <topology>%s</topology>
		    <predecessor_topology>%s</predecessor_topology>
		    <name>%s</name>children
		    <description>%s (%s)</description>
		    <calibrationPipelineAttributes>
		      <defaultTemplate>%s</defaultTemplate>
		      <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		      <timeIntegrationStep>%s</timeIntegrationStep>
		      <demixFreqStep>%s</demixFreqStep>
		      <demixTimeStep>%s</demixTimeStep>
		      <flagAutocorrelations>true</flagAutocorrelations>
		      <skyModelDatabase>%s</skyModelDatabase>
		      <demixing>%s</demixing>
		      <calibratorSource></calibratorSource>
		      <nrOfOutputCorrelated>%s</nrOfOutputCorrelated>
		    </calibrationPipelineAttributes>
		    <usedDataProducts>
		      <item>
			<lofar:uvDataProduct topology="%s">
			</lofar:uvDataProduct>
		      </item>
		    </usedDataProducts>
		    <resultDataProducts>
		      <item>
			<lofar:%s>
			  <name>%s</name>
			  <topology>%s</topology>
			  <status>no_data</status>
			</lofar:%s>
		      </item>
		    </resultDataProducts>
		  </lofar:pipeline>
		</item>""" % (
		# ****** CALIBRATION PIPELINE ******
		cal_pipe_target_topology,		# <topology>%s</topology>
		tar_obs_topology,		# <predecessor_topology>%s</predecessor_topology>
		cal_pipe_target_name,			# <name>Calibration Pipeline %s</name>
		cal_pipe_target_name,cal_pipe_target_description,	# <description>Calibration Pipeline %s</description>
		cal_tar_pipe_default_template, # <defaultTemplate>
		calibratorBeam[7],		# <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		calibratorBeam[8],		# <timeIntegrationStep>%s</timeIntegrationStep>
		calibratorBeam[9],		# <demixFreqStep>%s</demixFreqStep>
		calibratorBeam[10],		# <demixTimeStep>%s</demixTimeStep>
		calibratorBeam[11],		# <skyModelDatabase>%s</skyModelDatabase>
		str(calibratorBeam[6]).lower(),		# <demixing>
		calibratorBeam[4],		# <nrOfOutputInstrumentModel>%s</nrOfOutputInstrumentModel>
		tar_obs_beam_data_topologies[nr_beams],	# <lofar:uvDataProduct topology="%s">
		cal_pipe_target_output_data_type,
		cal_pipe_target_output_data_topo,	# <name>%s</name>
		cal_pipe_target_output_data_topo,	# <topology>%s</topology>
		cal_pipe_target_output_data_type,
		)
	else:    
	  print >> ofile, r"""</children>
	      </lofar:observation>
	      </item>"""


	for beamNr in range(0, nr_beams):
	  create_pipeline = targetBeams[beamNr][5]
	  if create_pipeline:
	    do_demix = targetBeams[beamNr][6]
	    if mode == 1 or mode == 2: # imaging modes
	      tar_pipe_default_template = "Calibration Pipeline Target"
	      tar_pipe_description = "Target Pipeline"
	    elif mode == 3:
	      if do_demix:
		tar_pipe_default_template = "Preprocess. Pipeline (demix)"
		tar_pipe_description = "Preprocessing,demixing"
	      else:
		tar_pipe_default_template = "Preprocess. Pipeline (no demix)"
		tar_pipe_description = "Preprocessing,averaging"
	    elif mode == 4:
	      if do_demix:
		tar_pipe_default_template = "Calibration Pipeline (demix)"
		tar_pipe_description = "Calibration,demixing"
	      else:
		tar_pipe_default_template = "Calibration Pipeline (no demix)"
		tar_pipe_description = "Calibration,averaging"

	    if writePackageTag:
	      tar_pipe_name = targetBeams[beamNr][2] + "/" + sliceStr + "." + str(beamNr) + "/TP"
	    else:
	      tar_pipe_name = packageTag + "/" + targetBeams[beamNr][2] + "/" + sliceStr + "." + str(beamNr) + "/TP"
	      
	    if mode == 1 or mode == 2:
	      print >> ofile, r"""<item index="0">
		<lofar:pipeline xsi:type="lofar:CalibrationPipelineType">
		  <topology>%s</topology>
		  <predecessor_topology>%s</predecessor_topology>
		  <name>%s</name>
		  <description>%s (%s)</description>
		  <calibrationPipelineAttributes>
		    <defaultTemplate>%s</defaultTemplate>
		    <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		    <timeIntegrationStep>%s</timeIntegrationStep>
		    <demixFreqStep>%s</demixFreqStep>
		    <demixTimeStep>%s</demixTimeStep>
		    <flagAutocorrelations>true</flagAutocorrelations>
		    <skyModelDatabase></skyModelDatabase>
		    <demixing>%s</demixing>
		    <calibratorSource>%s</calibratorSource>
		    <nrOfOutputCorrelated>%s</nrOfOutputCorrelated>
		  </calibrationPipelineAttributes>
		  <usedDataProducts>
		    <item>
		      <lofar:uvDataProduct topology="%s">
			<name>%s</name>
		      </lofar:uvDataProduct>
		    </item>
		    <item>
		      <lofar:instrumentModelDataProduct topology="%s">
			<name>%s</name>
		      </lofar:instrumentModelDataProduct>
		    </item>
		    </usedDataProducts>
		    <resultDataProducts>
		      <item>
			<lofar:uvDataProduct>
			  <name>%s</name>
			  <topology>%s</topology>
			  <status>no_data</status>
			</lofar:uvDataProduct>
		      </item>	
		    </resultDataProducts>		
		  </lofar:pipeline>
		</item>""" % (
		    # ****** TARGET PIPELINE ******
		    tar_pipe_topologies[beamNr],		# <topology>%s</topology>
		    tar_pipe_predecessor,	# <predecessor_topology>%s</predecessor_topology>
		    tar_pipe_name,			# <name>Target Pipeline %s</name>
		    tar_pipe_name,tar_pipe_description,		# <description>Target Pipeline %s</description>
		    tar_pipe_default_template,		# <defaultTemplate>%s</defaultTemplate>
		    targetBeams[beamNr][7],		# <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		    targetBeams[beamNr][8],		# <timeIntegrationStep>%s</timeIntegrationStep>
		    targetBeams[beamNr][9],		# <demixFreqStep>%s</demixFreqStep>
		    targetBeams[beamNr][10],		# <demixTimeStep>%s</demixTimeStep>
		    str(do_demix).lower(),		# <demixing>
		    calibratorBeam[11],			# <calibratorSource>%s</calibratorSource>
		    targetBeams[beamNr][4],		# <nrOfOutputCorrelated>%s</nrOfOutputCorrelated>
		    tar_obs_beam_data_topologies[beamNr],	# <lofar:uvDataProduct topology="%s"> (input MS topology)
		    tar_obs_beam_data_topologies[beamNr],	# <name>%s</name> (input MS topology)
		    tar_pipe_input_inst_topo,		# <lofar:instrumentModelDataProduct topology="%s"> (input instrument model topology)
		    tar_pipe_input_inst_topo,		# <name>%s</name> (input instrument model topology)
		    tar_pipe_output_data_topologies[beamNr],# <name>%s</name> (output MS topology)
		    tar_pipe_output_data_topologies[beamNr]	# <topology>%s</topology> (output MS topology)
		    )
		    
	    elif mode == 3:
	      print >> ofile, r"""<item index="0">
		<lofar:pipeline xsi:type="lofar:AveragingPipelineType">
		  <topology>%s</topology>
		  <predecessor_topology>%s</predecessor_topology>
		  <name>%s</name>
		  <description>%s (%s)</description>
		  <averagingPipelineAttributes>
		    <defaultTemplate>%s</defaultTemplate>
		    <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		    <timeIntegrationStep>%s</timeIntegrationStep>
		    <demixFreqStep>%s</demixFreqStep>
		    <demixTimeStep>%s</demixTimeStep>
		    <flagAutocorrelations>true</flagAutocorrelations>
		    <demixing>%s</demixing>
		    <nrOfOutputCorrelated>%s</nrOfOutputCorrelated>
		  </averagingPipelineAttributes>
		  <usedDataProducts>
		    <item>
		      <lofar:uvDataProduct topology="%s">
			<name>%s</name>
		      </lofar:uvDataProduct>
		    </item>
		    </usedDataProducts>
		    <resultDataProducts>
		      <item>
			<lofar:uvDataProduct>
			  <name>%s</name>
			  <topology>%s</topology>
			  <status>no_data</status>
			</lofar:uvDataProduct>
		      </item>	
		    </resultDataProducts>		
		  </lofar:pipeline>
		</item>""" % (
		    # ****** TARGET PIPELINE ******
		    tar_pipe_topologies[beamNr],		# <topology>%s</topology>
		    tar_pipe_predecessor,	# <predecessor_topology>%s</predecessor_topology>
		    tar_pipe_name,			# <name>Target Pipeline %s</name>
		    tar_pipe_name,tar_pipe_description,		# <description>Target Pipeline %s</description>
		    tar_pipe_default_template,		# <defaultTemplate>%s</defaultTemplate>
		    targetBeams[beamNr][7],		# <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		    targetBeams[beamNr][8],		# <timeIntegrationStep>%s</timeIntegrationStep>
		    targetBeams[beamNr][9],		# <demixFreqStep>%s</demixFreqStep>
		    targetBeams[beamNr][10],		# <demixTimeStep>%s</demixTimeStep>
		    str(do_demix).lower(),		# <demixing>
		    targetBeams[beamNr][4],		# <nrOfOutputCorrelated>%s</nrOfOutputCorrelated>
		    tar_obs_beam_data_topologies[beamNr],	# <lofar:uvDataProduct topology="%s"> (input MS topology)
		    tar_obs_beam_data_topologies[beamNr],	# <name>%s</name> (input MS topology)
		    tar_pipe_output_data_topologies[beamNr],# <name>%s</name> (output MS topology)
		    tar_pipe_output_data_topologies[beamNr]	# <topology>%s</topology> (output MS topology)
		    )
		    
	    elif mode == 4:
	      print >> ofile, r"""<item index="0">
		<lofar:pipeline xsi:type="lofar:CalibrationPipelineType">
		  <topology>%s</topology>
		  <predecessor_topology>%s</predecessor_topology>
		  <name>%s</name>
		  <description>%s (%s)</description>
		  <calibrationPipelineAttributes>
		    <defaultTemplate>%s</defaultTemplate>
		    <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		    <timeIntegrationStep>%s</timeIntegrationStep>
		    <demixFreqStep>%s</demixFreqStep>
		    <demixTimeStep>%s</demixTimeStep>
		    <flagAutocorrelations>true</flagAutocorrelations>
		    <skyModelDatabase>%s</skyModelDatabase>
		    <demixing>%s</demixing>
		    <calibratorSource></calibratorSource>
		    <nrOfOutputCorrelated>%s</nrOfOutputCorrelated>
		  </calibrationPipelineAttributes>
		  <usedDataProducts>
		    <item>
		      <lofar:uvDataProduct topology="%s">
			<name>%s</name>
		      </lofar:uvDataProduct>
		    </item>
		    </usedDataProducts>
		    <resultDataProducts>
		      <item>
			<lofar:uvDataProduct>
			  <name>%s</name>
			  <topology>%s</topology>
			  <status>no_data</status>
			</lofar:uvDataProduct>
		      </item>	
		    </resultDataProducts>		
		  </lofar:pipeline>
		</item>""" % (
		    # ****** TARGET PIPELINE ******
		    tar_pipe_topologies[beamNr],		# <topology>%s</topology>
		    tar_pipe_predecessor,	# <predecessor_topology>%s</predecessor_topology>
		    tar_pipe_name,			# <name>Target Pipeline %s</name>
		    tar_pipe_name,tar_pipe_description,		# <description>Target Pipeline %s</description>
		    tar_pipe_default_template,		# <defaultTemplate>%s</defaultTemplate>
		    targetBeams[beamNr][7],		# <frequencyIntegrationStep>%s</frequencyIntegrationStep>
		    targetBeams[beamNr][8],		# <timeIntegrationStep>%s</timeIntegrationStep>
		    targetBeams[beamNr][9],		# <demixFreqStep>%s</demixFreqStep>
		    targetBeams[beamNr][10],		# <demixTimeStep>%s</demixTimeStep>
		    targetBeams[beamNr][11],		# <skyModelDatabase>%s</skyModelDatabase>
		    str(do_demix).lower(),		# <demixing>
		    targetBeams[beamNr][4],		# <nrOfOutputCorrelated>%s</nrOfOutputCorrelated>
		    tar_obs_beam_data_topologies[beamNr],	# <lofar:uvDataProduct topology="%s"> (input MS topology)
		    tar_obs_beam_data_topologies[beamNr],	# <name>%s</name> (input MS topology)
		    tar_pipe_output_data_topologies[beamNr],# <name>%s</name> (output MS topology)
		    tar_pipe_output_data_topologies[beamNr]	# <topology>%s</topology> (output MS topology)
		    )

		    
      if do_imaging:
	for beamNr in range (0, nr_beams):
	  create_pipeline = targetBeams[beamNr][5]
	  if create_pipeline:
	    beamNrStr = str(beamNr)
	    imaging_pipe_topology = blockTopo + 'PI' + beamNrStr				# 1.PI
	    imaging_pipe_output_topology = imaging_pipe_topology + '.dps'	# 1.PI.dps
	    #for i in range(0, len(imaging_pipe_predecessors[beamNr])-1):
	    imaging_pipe_predecessors_string = ''
	    for sliceNr in range (0, nrSlices-1):
	      imaging_pipe_predecessors_string = imaging_pipe_predecessors_string + imaging_pipe_predecessors[beamNr][sliceNr] + ','

	    imaging_pipe_predecessors_string = imaging_pipe_predecessors_string + imaging_pipe_predecessors[beamNr][len(imaging_pipe_predecessors[beamNr])-1]

	    #for sliceNr in range (1, nrSlices+1): 
	      #sliceStr = str(sliceNr)
	      # ****** ADD AN IMAGING PIPELINE FOR EVERY TARGET BEAM ******

	    if writePackageTag:
	      imaging_pipe_name = targetBeams[beamNr][2] + "/IM"
	    else:
	      imaging_pipe_name = packageTag + "/" + targetBeams[beamNr][2] + "/IM"
	      
	    print >> ofile, r"""<item index="0">
		  <lofar:pipeline xsi:type="lofar:ImagingPipelineType">
		    <topology>%s</topology>
		    <predecessor_topology>%s</predecessor_topology>
		    <name>%s</name>
		    <description>%s (Imaging pipeline beam %s)</description>
		    <imagingPipelineAttributes>
		      <defaultTemplate>%s</defaultTemplate>
		      <frequencyIntegrationStep>1</frequencyIntegrationStep>
		      <calibrationStrategy>My Calibration Strategy</calibrationStrategy>
		      <numberOfMajorCycles>1</numberOfMajorCycles>
		      <nrSlicesPerImage>%s</nrSlicesPerImage>
		      <nrSubbandsPerImage>%s</nrSubbandsPerImage>
		      <demixing>true</demixing>
		      <nrOfOutputSkyImage>%s</nrOfOutputSkyImage>
		    </imagingPipelineAttributes>
		    <usedDataProducts>""" % (imaging_pipe_topology, imaging_pipe_predecessors_string, imaging_pipe_name, imaging_pipe_name, beamNr, imaging_pipe_default_template, nrSlices, nrSubbandsPerImage, nrImages[beamNr])
		      
	    for i in range(0, len(imaging_pipe_inputs[beamNr])):
	      print >> ofile, r"""                <item>
			<lofar:uvDataProduct topology="%s">
			  <name>%s</name>
			</lofar:uvDataProduct>
		      </item>""" % (imaging_pipe_inputs[beamNr][i], imaging_pipe_inputs[beamNr][i])

	    print >> ofile, r"""               </usedDataProducts>
		    <resultDataProducts>
		      <item>
			<lofar:skyImageDataProduct>
			  <name>%s</name>
			  <topology>%s</topology>
			  <status>no_data</status>
			</lofar:skyImageDataProduct>
		      </item>
		    </resultDataProducts>
		  </lofar:pipeline>
		</item>""" % (imaging_pipe_output_topology, imaging_pipe_output_topology)

      print >> ofile, r"""</children>
      </lofar:folder>
      </item>"""
      
      print "\n"
      blockNr += 1
		
  except:
    import traceback
    traceback.print_exc()
    print "something went wrong here, now aborting"
    ifile.close()
    exit(1)

  if createMainFolder:
    print >> ofile, r"""</children>
    </lofar:folder>
    </item>"""

  print >> ofile, r"""          </children>
  </lofar:project>"""

  ofile.close()
    
if __name__ == "__main__":
   main(sys.argv[1:])
    
